# Blaz Booth Agent

This is a lightweight HTML page to embed the Blaz Entertainment booth booking chatbot powered by Google Cloud Conversational Agent.

## How to Publish

1. Fork this repo or upload the contents to your own GitHub repo.
2. Go to `Settings > Pages` and set the source to `main` branch and root (`/`) folder.
3. Your bot will be live at `https://<your-username>.github.io/<repo-name>/`